#ifndef __OLA_H__
#define __OLA_H__

void say_hello();

#endif
