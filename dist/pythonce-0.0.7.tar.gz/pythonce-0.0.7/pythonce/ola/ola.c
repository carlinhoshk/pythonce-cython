#include "ola.h"
#include <stdio.h>


void say_hello() {
        printf("Olá Milene \U0001F918\n");
    }
