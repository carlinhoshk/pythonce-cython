from .ola.wrap_ola import ola

from .calculator.cal import soma, subtracao, multiplicacao, divisao