This is a hello world c into python library 
